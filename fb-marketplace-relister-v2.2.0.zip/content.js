'use strict';

// content.js v2.2.0 — Direct Facebook GraphQL API (no UI form interaction)
// Runs only on: /marketplace/you/selling

const SELLING_URL = 'https://www.facebook.com/marketplace/you/selling';
const RELIST_CLASS = 'fbr-relist-btn';

// ─── State ────────────────────────────────────────────────────────────────────
let _tokens = null;
let _docIds = null;
let _relistInProgress = false;

// ─── Tokens / DocIDs (via background) ────────────────────────────────────────

async function getTokens() {
  if (_tokens) return _tokens;
  const result = await chrome.runtime.sendMessage({ kind: 'GET_TOKENS' });
  if (result?.error) throw new Error(result.error);
  _tokens = result;
  return _tokens;
}

async function getDocIds(listingId) {
  if (_docIds) return _docIds;
  const result = await chrome.runtime.sendMessage({ kind: 'GET_DOC_IDS', listingId });
  if (result?.error) throw new Error(result.error);
  _docIds = result;
  return _docIds;
}

// ─── GraphQL ──────────────────────────────────────────────────────────────────

function isAuthError(text) {
  return text.includes('"error_code":1357004') ||
         text.includes('"error_code":190')     ||
         text.includes('OAuthException')        ||
         text.includes('Session has expired');
}

async function fbGraphQL(referrer, docId, mutationName, variables, _retry = 0) {
  const t = await getTokens();
  const body = new URLSearchParams({
    av:                       t.user_id,
    __a:                      '1',
    __comet_req:              '1',
    fb_dtsg:                  t.fb_dtsg,
    fb_api_caller_class:      'RelayModern',
    fb_api_req_friendly_name: mutationName,
    variables:                JSON.stringify(variables),
    doc_id:                   docId
  }).toString();

  let res;
  try {
    res = await fetch('https://www.facebook.com/api/graphql/', {
      method: 'POST',
      headers: { accept: '*/*', 'content-type': 'application/x-www-form-urlencoded' },
      referrer,
      referrerPolicy: 'strict-origin-when-cross-origin',
      body,
      mode: 'cors',
      credentials: 'include'
    });
  } catch (netErr) {
    if (_retry < 2) {
      await new Promise(r => setTimeout(r, (1 + _retry) * 1000));
      return fbGraphQL(referrer, docId, mutationName, variables, _retry + 1);
    }
    throw netErr;
  }

  if (res.status >= 500 && _retry < 2) {
    await new Promise(r => setTimeout(r, (1 + _retry) * 1000));
    return fbGraphQL(referrer, docId, mutationName, variables, _retry + 1);
  }

  const text = await res.text();

  if (isAuthError(text)) {
    _tokens = null;
    _docIds = null;
    chrome.runtime.sendMessage({ kind: 'CLEAR_CACHE' }).catch(() => {});
    throw new Error('Facebook session expired — please refresh and try again');
  }

  // Strip FB's anti-CSRF prefix: "for (;;);" or "while(1);"
  const clean = text.replace(/^(?:for\s*\(;;\)|while\s*\(1\));/, '').trim();
  try {
    return JSON.parse(clean);
  } catch {
    throw new Error('Could not parse GraphQL response');
  }
}

// ─── Deep JSON search ─────────────────────────────────────────────────────────

function deepFind(obj, key, seen) {
  if (!obj || typeof obj !== 'object') return null;
  if (!seen) seen = new Set();
  if (seen.has(obj)) return null;
  seen.add(obj);
  if (Object.prototype.hasOwnProperty.call(obj, key)) return obj[key];
  for (const v of Object.values(obj)) {
    const found = deepFind(v, key, seen);
    if (found != null) return found;
  }
  return null;
}

// ─── Read listing data ────────────────────────────────────────────────────────

async function readDetailPage(listingId) {
  const res = await fetch(`https://www.facebook.com/marketplace/item/${listingId}/`, {
    method: 'GET',
    credentials: 'include',
    referrerPolicy: 'strict-origin-when-cross-origin'
  });
  const html = await res.text();
  const doc  = new DOMParser().parseFromString(html, 'text/html');
  const scripts = Array.from(doc.getElementsByTagName('script'))
    .filter(s => s.type === 'application/json');

  for (const s of scripts) {
    try {
      const data  = JSON.parse(s.textContent || '{}');
      const found = deepFind(data, 'marketplace_product_details_page');
      if (found) return found;
    } catch {}
  }
  return null;
}

async function readComposerData(listingId, ids) {
  if (!ids.read_id) return null;
  try {
    const json = await fbGraphQL(
      SELLING_URL,
      ids.read_id,
      'CometMarketplaceComposerRootComponentQuery',
      {
        listingId,
        is_edit: true,
        composer_mode: 'EDIT_LISTING',
        scale: 1,
        prefill_id: '0',
        category_id: '0',
        has_prefill_data: false,
        has_prefetched_category: false,
        delivery_types: ['in_person']
      }
    );
    return json?.data?.listing ?? null;
  } catch (e) {
    console.warn('[Relister] Composer query failed — using detail page only:', e.message);
    return null;
  }
}

// ─── Build create-mutation payload ───────────────────────────────────────────

function parsePrice(amount) {
  // Strip locale commas (e.g. "1,234") before dropping decimals
  return String(amount ?? '0').replace(/,/g, '').replace(/\.\d+$/, '');
}

function buildListingData(detail, composer) {
  const target = detail?.target ?? {};
  const c      = composer ?? {};

  const categoryId = String(
    c.marketplace_listing_virtual_taxonomy_category?.id ??
    c.marketplace_listing_category_id ??
    target.marketplace_listing_category_id ??
    ''
  );

  const title       = String(c.marketplace_listing_title ?? target.marketplace_listing_title ?? '');
  const description = String(c.redacted_description ?? target.redacted_description ?? target.description ?? '');
  const price       = parsePrice(target.listing_price?.amount);
  const currency    = String(target.listing_price?.currency ?? 'USD');
  const latitude    = Number(target.location?.latitude  ?? 0);
  const longitude   = Number(target.location?.longitude ?? 0);

  const photoSources = c.listing_photos ?? target.listing_photos ?? [];
  const photoIds     = photoSources.map(p => String(p.id)).filter(Boolean);

  const hiddenFromFriends = String(c.hidden_from_friends ?? target.hidden_from_friends_visibility ?? 'HIDDEN_FROM_FRIENDS');

  // Handle plain array, .edges, or .nodes for hashtags
  const hashtagSource = c.marketplace_hashtags ?? target.marketplace_hashtags ?? {};
  const hashtagItems  = Array.isArray(hashtagSource)
    ? hashtagSource
    : (hashtagSource.edges ?? hashtagSource.nodes ?? []);
  const hashtags = hashtagItems.map(h => h.tag_name).filter(Boolean);

  const attrArray = c.attribute_data ?? target.attribute_data ?? [];
  const vtAttrs   = { vt_attributes_free_form: {}, vt_attributes_normalized: {} };
  for (const attr of attrArray) {
    if (attr.attribute_type === 'DYNAMIC' && attr.attribute_id && attr.attribute_value_id) {
      vtAttrs.vt_attributes_normalized[attr.attribute_id] = attr.attribute_value_id;
    } else if (attr.attribute_name) {
      vtAttrs.vt_attributes_free_form[attr.attribute_name] = attr.value ?? attr.attribute_value ?? '';
    }
  }

  const sku = String(c.sku ?? target.sku ?? '1');

  return {
    title,
    description,
    category_id: categoryId,
    item_price: { currency, price },
    latitude,
    longitude,
    attribute_data_json: JSON.stringify(vtAttrs),
    delivery_types: ['in_person'],
    hidden_from_friends_visibility: hiddenFromFriends,
    product_hashtag_names: hashtags,
    photo_ids: photoIds,
    video_ids: [],
    sku,
    // Composer surface constants required by FB API
    surface: 'composer',
    is_preview: false,
    is_personalization_required: null,
    personalization_info: null,
    draft_type: null,
    quantity: null,
    cost_per_additional_item: null,
    comparable_price: null,
    min_acceptable_checkout_offer_price: null,
    suggested_hashtag_names: [],
    variants: [],
    xpost_target_ids: [],
    // Shipping constants (in_person only — all disabled)
    shipping_offered: false,
    shipping_cost_option: 'BUYER_PAID_SHIPPING',
    shipping_price: null,
    shipping_label_price: '0',
    shipping_label_rate_code: null,
    shipping_label_rate_type: null,
    shipping_service_type: null,
    shipping_package_weight: null,
    shipping_options_data: [],
    shipping_calculation_logic_version: null,
    shipping_cost_range_lower_cost: null,
    shipping_cost_range_upper_cost: null,
    commerce_shipping_carrier: null,
    commerce_shipping_carriers: []
  };
}

// ─── Daily session counter ────────────────────────────────────────────────────

async function incrementRelistCount() {
  const today = new Date().toISOString().slice(0, 10);
  const data  = await chrome.storage.local.get(['relistCount', 'relistCountDate']);
  const count = (data.relistCountDate === today ? (data.relistCount || 0) : 0) + 1;
  await chrome.storage.local.set({ relistCount: count, relistCountDate: today });
}

// ─── Mutations ────────────────────────────────────────────────────────────────

async function deleteListing(listingId, ids) {
  const t    = await getTokens();
  const json = await fbGraphQL(
    SELLING_URL,
    ids.delete_id,
    'useCometMarketplaceForSaleItemDeleteMutation',
    {
      input: {
        client_mutation_id: '-1',
        actor_id: t.user_id,
        batch_delete_variants: true,
        for_sale_item_id: listingId,
        referral_surface: 'MARKETPLACE_INSIGHTS',
        surface: 'MARKETPLACE_PAGE_SELLING'
      }
    }
  );
  if (json?.errors?.length) throw new Error('Delete failed: ' + json.errors[0]?.message);
}

async function createListing(listingData, ids) {
  const t    = await getTokens();
  const json = await fbGraphQL(
    'https://www.facebook.com/marketplace/create/item',
    ids.create_id,
    'useCometMarketplaceListingCreateMutation',
    {
      input: {
        client_mutation_id: '-1',
        actor_id: t.user_id,
        audience: { marketplace: { marketplace_id: t.marketplace_id } },
        data: { common: listingData }
      }
    }
  );
  if (json?.errors?.length) {
    _docIds = null; // bust cached doc IDs on create failure so next attempt re-fetches fresh ones
    throw new Error('Create failed: ' + json.errors[0]?.message);
  }
  return json?.data?.marketplace_listing_create?.listing?.id ?? null;
}

// ─── Relist orchestration ─────────────────────────────────────────────────────

async function relistItem(listingId, btn) {
  const setStep = (text, state) => {
    btn.textContent      = text;
    btn.dataset.state    = state || 'busy';
    btn.disabled         = (state === 'busy' || state === 'done');
    btn.style.background = state === 'error' ? '#c62828' : state === 'done' ? '#2e7d32' : '#1877f2';
    chrome.storage.local.set({ status: text, statusTime: Date.now() });
  };

  if (_relistInProgress) {
    btn.textContent = 'Please wait…';
    setTimeout(() => { btn.textContent = 'Relist'; }, 2000);
    return;
  }
  _relistInProgress = true;

  try {
    setStep('Loading…', 'busy');
    const ids = await getDocIds(listingId);

    setStep('Reading…', 'busy');
    const [detail, composer] = await Promise.all([
      readDetailPage(listingId),
      readComposerData(listingId, ids)
    ]);

    if (!detail) throw new Error('Could not read listing data');

    const listingData = buildListingData(detail, composer);
    if (!listingData.title)                  throw new Error('Listing has no title');
    if (!listingData.category_id)            throw new Error('Listing has no category');
    if (listingData.photo_ids.length === 0)  throw new Error('No photos found — cannot relist');

    // Create first — if delete fails, original listing is still live (no data loss)
    setStep('Posting…', 'busy');
    const newId = await createListing(listingData, ids);

    setStep('Deleting…', 'busy');
    await deleteListing(listingId, ids);

    await incrementRelistCount();
    await chrome.storage.local.set({
      status: `Relisted ✓ new ID: ${newId}`,
      statusTime: Date.now(),
      lastNewId: newId
    });

    setStep('Done ✓', 'done');
    _relistInProgress = false;
    setTimeout(() => location.reload(), 2000);

  } catch (e) {
    _relistInProgress = false;
    btn.textContent      = 'Error ✗';
    btn.dataset.state    = 'error';
    btn.disabled         = false;
    btn.style.background = '#c62828';
    btn.style.opacity    = '1';
    chrome.storage.local.set({ status: `Error: ${e.message}`, statusTime: Date.now() });
    console.error('[Relister v2.2.0]', e);
    setTimeout(() => {
      btn.textContent      = 'Relist';
      btn.dataset.state    = '';
      btn.style.background = '#1877f2';
      btn.disabled         = false;
    }, 4000);
  }
}

// ─── UI injection ─────────────────────────────────────────────────────────────

function getListingId(href) {
  const m = (href || '').match(/\/marketplace\/item\/(\d+)/);
  return m ? m[1] : null;
}

function injectButton(anchor) {
  const listingId = getListingId(anchor.href);
  if (!listingId) return;

  // Walk up to find the card container (first positioned ancestor)
  let card = anchor.parentElement || anchor;
  for (let i = 0; i < 8; i++) {
    const p = card.parentElement;
    if (!p || p === document.body) break;
    const style = getComputedStyle(p);
    if (style.position !== 'static') {
      card = p;  // use the positioned element — it's the actual card
      break;
    }
    card = p;
  }

  if (card.querySelector('.' + RELIST_CLASS)) return;

  const btn = document.createElement('button');
  btn.className = RELIST_CLASS;
  btn.textContent = 'Relist';
  btn.title = 'Delete & re-post this listing';
  btn.setAttribute('aria-label', 'Relist this item on Marketplace');
  btn.style.cssText = [
    'position:absolute',
    'bottom:8px',
    'right:8px',
    'z-index:9999',
    'background:#1877f2',
    'color:#fff',
    'border:none',
    'border-radius:6px',
    'padding:7px 13px',
    'font-size:12px',
    'font-weight:700',
    'cursor:pointer',
    'box-shadow:0 2px 8px rgba(0,0,0,.45)',
    'line-height:1.5',
    'opacity:0.85',
    'transition:opacity .18s, background .15s'
  ].join(';');

  // Full opacity on card hover
  card.addEventListener('mouseenter', () => {
    if (btn.dataset.state !== 'busy' && btn.dataset.state !== 'done') {
      btn.style.opacity = '1';
    }
  });
  card.addEventListener('mouseleave', () => {
    if (!btn.dataset.state && btn.dataset.confirm !== '1') {
      btn.style.opacity = '0.85';
    }
  });

  btn.addEventListener('mouseenter', () => {
    if (!btn.dataset.state && btn.dataset.confirm !== '1') btn.style.background = '#166fe5';
  });
  btn.addEventListener('mouseleave', () => {
    if (!btn.dataset.state && btn.dataset.confirm !== '1') btn.style.background = '#1877f2';
  });

  // Two-click confirm pattern: first click → amber "Confirm?", second → execute, auto-cancel after 3s
  let confirmTimer = null;

  btn.addEventListener('click', e => {
    e.preventDefault();
    e.stopPropagation();

    if (btn.dataset.confirm === '1') {
      clearTimeout(confirmTimer);
      btn.dataset.confirm  = '';
      btn.style.background = '#1877f2';
      relistItem(listingId, btn);
      return;
    }

    btn.dataset.confirm  = '1';
    btn.textContent      = 'Confirm?';
    btn.style.background = '#d97706';
    btn.style.opacity    = '1';

    confirmTimer = setTimeout(() => {
      if (btn.dataset.confirm === '1') {
        btn.dataset.confirm  = '';
        btn.textContent      = 'Relist';
        btn.style.background = '#1877f2';
        btn.style.opacity    = '0';
      }
    }, 3000);
  });

  if (getComputedStyle(card).position === 'static') card.style.position = 'relative';
  card.appendChild(btn);
}

function scanListings() {
  document.querySelectorAll('a[href*="/marketplace/item/"]:not([data-fbr-scanned])').forEach(a => {
    a.setAttribute('data-fbr-scanned', '1');
    injectButton(a);
  });
}

// ─── Init ─────────────────────────────────────────────────────────────────────

const _observer = new MutationObserver(scanListings);
_observer.observe(document.body, { childList: true, subtree: true });
scanListings();

// Pre-warm tokens so first click is instant
chrome.runtime.sendMessage({ kind: 'GET_TOKENS' }).catch(() => {});
