// utils.js — Shared utilities for FB Marketplace Relister

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

const SHORT  = () => 500  + Math.random() * 500;
const MEDIUM = () => 1000 + Math.random() * 1000;
const LONG   = () => 2500 + Math.random() * 1500;

async function scrollAndClick(el) {
  el.scrollIntoView({ behavior: 'smooth', block: 'center' });
  await sleep(300 + Math.random() * 200);
  el.click();
}

function spanTextFinder(fieldName, tagName = 'input') {
  const spans = Array.from(document.querySelectorAll('span'));
  const matchSpan = spans.find(s => s.textContent.trim() === fieldName);
  if (!matchSpan) return null;

  let node = matchSpan;
  for (let i = 0; i < 6; i++) {
    node = node.parentElement;
    if (!node) break;
    const found = node.querySelector(tagName);
    if (found) return found;
  }
  return null;
}

// MAIN world bridge fill — hook.js (MAIN world) handles the actual set + React event dispatch.
// Isolated world cannot reliably update React state via prototype setters or execCommand.
var _fillIdSeq = 0;

function _bridgeFill(el, value) {
  el.focus();
  var fillId = 'fbr' + (++_fillIdSeq) + '_' + Date.now();
  el.setAttribute('data-fbr-fill', fillId);
  window.postMessage({ __fbRelister: 'fillField', fillId: fillId, value: value }, '*');
  // Attribute removed by hook.js after processing, or cleaned up here after a short delay
  setTimeout(function () { el.removeAttribute('data-fbr-fill'); }, 300);
}

function nativeSetInput(inputEl, value) {
  _bridgeFill(inputEl, value);
}

function nativeSetTextarea(textareaEl, value) {
  _bridgeFill(textareaEl, value);
}

async function typeSlowly(el, text) {
  el.focus();
  for (const char of text) {
    const current = el.value;
    _bridgeFill(el, current + char);
    await sleep(100 + Math.random() * 50);
  }
}

async function waitForElement(selector, timeoutMs = 10000) {
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    const el = document.querySelector(selector);
    if (el) return el;
    await sleep(200);
  }
  return null;
}

async function waitForElementGone(selector, timeoutMs = 10000) {
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    const el = document.querySelector(selector);
    if (!el) return true;
    await sleep(200);
  }
  return false;
}

function findRoleOption(optionText) {
  const options = Array.from(document.querySelectorAll('div[role="option"]'));
  return options.find(
    o => o.textContent.trim().toLowerCase() === optionText.trim().toLowerCase()
  ) || null;
}

function setStatus(message) {
  chrome.storage.local.set({ status: message, statusTime: Date.now() });
}

function setProgress(done, total) {
  chrome.storage.local.set({ progressDone: done, progressTotal: total });
}
