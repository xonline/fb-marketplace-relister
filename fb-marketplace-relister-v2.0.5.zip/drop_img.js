// drop_img.js — Photo upload via direct file input (preferred) with DragEvent fallback
// Depends on: utils.js (sleep, setStatus)

function base64ToFile(base64, filename) {
  const arr = base64.split(',');
  const mimeMatch = arr[0].match(/:(.*?);/);
  const mime = mimeMatch ? mimeMatch[1] : 'image/jpeg';
  const bstr = atob(arr[1] !== undefined ? arr[1] : arr[0]);
  const n = bstr.length;
  const u8arr = new Uint8Array(n);
  for (let i = 0; i < n; i++) {
    u8arr[i] = bstr.charCodeAt(i);
  }
  return new File([u8arr], filename, { type: mime });
}

function simulateFileDrop(targetEl, fileObj) {
  const dataTransfer = new DataTransfer();
  dataTransfer.items.add(fileObj);

  const eventOptions = {
    bubbles: true,
    cancelable: true,
    composed: true,
    dataTransfer,
  };

  targetEl.dispatchEvent(new DragEvent('dragenter', { ...eventOptions, clientX: 1, clientY: 1 }));
  targetEl.dispatchEvent(new DragEvent('dragover',  { ...eventOptions, clientX: 1, clientY: 2 }));
  targetEl.dispatchEvent(new DragEvent('drop',      { ...eventOptions, clientX: 1, clientY: 2 }));
}

async function downloadImageAsFile(photoUrl, index) {
  const base64Data = await new Promise((resolve, reject) => {
    chrome.runtime.sendMessage(
      { action: 'downloadImage', url: photoUrl },
      response => {
        if (chrome.runtime.lastError) reject(chrome.runtime.lastError);
        else if (response && response.data) resolve(response.data);
        else reject(new Error('No data received from background'));
      }
    );
  });
  return base64ToFile(base64Data, `photo-${index}.jpg`);
}

async function uploadAllPhotos(photoUrls) {
  if (!photoUrls || photoUrls.length === 0) return;

  // Strategy 1: Direct file input — batch all photos at once (competitor-proven approach)
  // Setting input.files replaces all files atomically; React picks up the change event.
  const photoInput = document.querySelector('input[accept="image/*,image/heif,image/heic"]');
  if (photoInput) {
    setStatus(`Downloading ${photoUrls.length} photo(s)...`);
    const dt = new DataTransfer();
    let downloaded = 0;
    for (let i = 0; i < photoUrls.length; i++) {
      try {
        const file = await downloadImageAsFile(photoUrls[i], i);
        dt.items.add(file);
        downloaded++;
      } catch (err) {
        console.warn(`[Relister] Photo ${i + 1} download failed:`, err);
      }
    }
    if (downloaded > 0) {
      setStatus(`Uploading ${downloaded} photo(s)...`);
      photoInput.files = dt.files;
      photoInput.dispatchEvent(new Event('change', { bubbles: true }));
      await sleep(3000);
      return;
    }
    console.warn('[Relister] All photo downloads failed — skipping upload');
    return;
  }

  // Strategy 2: DragEvent simulation fallback (one at a time)
  const dropTarget = document.querySelector('div[aria-label="Add photos or videos"]');
  if (!dropTarget) {
    console.error('[Relister] Could not find photo input or drop zone');
    return;
  }

  for (let i = 0; i < photoUrls.length; i++) {
    setStatus(`Uploading photo ${i + 1}/${photoUrls.length}...`);
    try {
      const file = await downloadImageAsFile(photoUrls[i], i);
      simulateFileDrop(dropTarget, file);
      await sleep(2000);
    } catch (err) {
      console.warn(`[Relister] Skipping photo ${i + 1}:`, err);
    }
    if (i < photoUrls.length - 1) await sleep(1000);
  }
}
