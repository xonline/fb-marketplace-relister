// hook.js — Runs in the PAGE's main world (world: "MAIN") so it can patch window.fetch/XHR
// and fill React-controlled inputs (isolated world cannot reliably trigger React onChange).
(function () {
  if (window.__fbRelisterHooked) return;
  window.__fbRelisterHooked = true;

  // ─── React input filler (called from content.js via postMessage) ──────────────
  // Isolated world cannot reliably trigger React's synthetic onChange because React's
  // _valueTracker closure lives in MAIN world. We fill fields here where everything
  // is in the same JS context as React.
  window.addEventListener('message', function (evt) {
    if (!evt.data || evt.data.__fbRelister !== 'fillField') return;
    var fillId = evt.data.fillId;
    var value  = String(evt.data.value == null ? '' : evt.data.value);
    if (!fillId) return;

    var el = document.querySelector('[data-fbr-fill="' + fillId + '"]');
    if (!el) { console.warn('[Relister] fillField: element not found for id', fillId); return; }

    el.focus();

    // Reset React's _valueTracker so getValueIfChanged() sees a change.
    // tracker.getValue() returns the last value React thinks the field had.
    // By resetting it to '' we guarantee the upcoming value is seen as new.
    var tracker = el._valueTracker;
    if (tracker) tracker.setValue('');

    // Set native value via the PROTOTYPE descriptor (not the own-property override
    // React installs). This sets the underlying DOM/C++ value without updating
    // currentValue, so React's subsequent getValueIfChanged() sees a delta.
    var proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    var desc = Object.getOwnPropertyDescriptor(proto, 'value');
    if (desc && desc.set) {
      desc.set.call(el, value);
    } else {
      el.value = value;
    }

    // Fire both events — React 16 uses 'input', older polyfills use 'change'.
    el.dispatchEvent(new Event('input',  { bubbles: true, cancelable: true }));
    el.dispatchEvent(new Event('change', { bubbles: true, cancelable: true }));
  });

  function relay(text) {
    if (text && (text.includes('marketplace') || text.includes('listing'))) {
      window.postMessage({ __fbRelister: 'graphql', text }, '*');
    }
  }

  // ─── fetch hook ───────────────────────────────────────────────────────────────
  const _fetch = window.fetch;
  window.fetch = async function (...args) {
    const url = typeof args[0] === 'string' ? args[0]
              : (args[0] && args[0].url) ? args[0].url : '';

    const res = await _fetch.apply(this, args);

    if (url.includes('/api/graphql')) {
      res.clone().text().then(t => relay(t)).catch(() => {});
    }

    return res;
  };

  // ─── XHR hook ─────────────────────────────────────────────────────────────────
  const _XHR = window.XMLHttpRequest;
  function PatchedXHR() {
    const xhr = new _XHR();
    let capturedUrl = '';

    const origOpen = xhr.open.bind(xhr);
    xhr.open = function (m, u) {
      capturedUrl = String(u);
      return origOpen.apply(this, arguments);
    };

    xhr.addEventListener('load', function () {
      if (capturedUrl.includes('/api/graphql')) {
        relay(xhr.responseText || '');
      }
    });

    return xhr;
  }
  PatchedXHR.prototype = _XHR.prototype;
  window.XMLHttpRequest = PatchedXHR;

  console.log('[Relister] main-world hook installed');
})();
